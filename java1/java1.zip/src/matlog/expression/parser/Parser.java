package matlog.expression.parser;

/**
 * @author Kochetkov Nikita M3234
 * Date: 17.03.2019
 */
public interface Parser {;
    Expression parse(String expression);
}