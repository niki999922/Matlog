package matlog.expression.proof.Exception;

/**
 * @author Kochetkov Nikita M3234
 * Date: 18.04.2019
 */
public class ProofException extends Exception {
    public ProofException() {
        super();
    }

    public ProofException(String message) {
        super(message);
    }
}
